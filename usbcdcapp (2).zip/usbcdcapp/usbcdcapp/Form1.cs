﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using usbcdcapp.Properties;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace usbcdcapp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            comboBox1.DataSource = SerialPort.GetPortNames();
        }

        private void button1_Click(object sender, EventArgs e)//open
        {
            if (!serialPort1.IsOpen)  //시리얼포트가 열려 있지 않으면
            {
                MessageBox.Show("port open");

                serialPort1.PortName = comboBox1.Text;  //콤보박스의 선택된 COM포트명을 시리얼포트명으로 지정
                serialPort1.BaudRate = int.Parse(comboBox2.SelectedItem.ToString());  //보레이트 변경이 필요하면 숫자 변경하기
                serialPort1.DataBits = 8;
                serialPort1.StopBits = StopBits.One;
                serialPort1.Parity = Parity.None;
                // serial = new SerialPort(comboBox1.Text, int.Parse(comboBox2.SelectedText));
                serialPort1.DataReceived += new SerialDataReceivedEventHandler(serialPort1_DataReceived);
                serialPort1.Open();
                serialPort1.DiscardInBuffer();
                //richTextBox1.AppendText("com port is opened ");
            }
            else
            {
                MessageBox.Show("port is already opened");
            }
        }

        private void button2_Click(object sender, EventArgs e)//close
        {
            //close
            MessageBox.Show("port closed");
            //SerialPort serial = new SerialPort(comboBox1.Text, 115200);
            //serial.Open();
            //serial.Write("LED3\n\r");
            serialPort1.Close();
        }
        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)  //수신 이벤트가 발생하면 이 부분이 실행된다.
        {
            this.Invoke(new EventHandler(MySerialReceived));  //메인 쓰레드와 수신 쓰레드의 충돌 방지를 위해 Invoke 사용. MySerialReceived로 이동하여 추가 작업 실행.
        }

        private void MySerialReceived(object s, EventArgs e)  //여기에서 수신 데이타를 사용자의 용도에 따라 처리한다.
        {
            //int ReceiveData = serialPort1.ReadByte();  //시리얼 버터에 수신된 데이타를 ReceiveData 읽어오기
            //richTextBox_received.Text = richTextBox_received.Text + string.Format("{0:X2}", ReceiveData);  //int 형식을 string형식으로 변환하여 출력
            string data = serialPort1.ReadLine();
            Console.WriteLine(data);
            string[] parts = data.Trim().Split(',');
            serialPort1.DiscardInBuffer();
            //richTextBox1.AppendText(data + Environment.NewLine);
            if (parts[0] == "a")
            {
                textBox2.Clear();
                //Console.WriteLine(parts[1]);
                textBox2.AppendText(parts[1] + Environment.NewLine);

            }

        }

        private void button3_Click(object sender, EventArgs e)//send
        {
            string textdata = textBox1.Text;//"e";
            serialPort1.Write(textdata.PadRight(20, '\n'));
        }

        private void button4_Click(object sender, EventArgs e)//Recieve
        {

        }

        private void button5_Click(object sender, EventArgs e)//fileread
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                richTextBox1.Text = File.ReadAllText(ofd.FileName);
                //LoadPropertySettings(ofd.FileName);
                //MessageBox.Show($"mainWndSx = {settings.mainWndSx}\nmainWndSy = {settings.mainWndSy}\nmainWndDx = {settings.mainWndDx}\nmainWndDy = {settings.mainWndDy}\n");
            }
        }

        private void button6_Click(object sender, EventArgs e)//filesend
        {

        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            textBox3.Text = trackBar1.Value.ToString();
            uint num = (UInt32)trackBar1.Value;
            byte[] senddata = new byte[20]; ;
            senddata[0] = (byte)'m';
            //UInt32 num;
            senddata[1] = (byte)(num >> 8);
            senddata[2] = (byte)(num &0xff);
            serialPort1.Write(senddata, 0, 20);
            //string textdata = textBox1.Text;//"e";
            //serialPort1.Write(textdata.PadRight(20, '\n'));
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            string textdata1 = "LED1";
            
            if (checkBox1.Checked) {
                textdata1 = textdata1 + "1";
            }
            else
            {
                textdata1 = textdata1 + "0";
            }
            //string textdata = "LED1";
            serialPort1.Write(textdata1.PadRight(20, '\n'));
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            string textdata2 = "LED2";
            if (checkBox2.Checked)
            {
                textdata2 = textdata2 + "1";
            }
            else
            {
                textdata2 = textdata2 + "0";
            }
            serialPort1.Write(textdata2.PadRight(20, '\n'));
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            string textdata3 = "LED3";
            if (checkBox3.Checked)
            {
                textdata3 = textdata3 + "1";
            }
            else
            {
                textdata3 = textdata3 + "0";
            }
            serialPort1.Write(textdata3.PadRight(20, '\n'));
        }
    }
}
